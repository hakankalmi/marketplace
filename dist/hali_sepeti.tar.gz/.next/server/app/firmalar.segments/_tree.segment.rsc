:HL["/_next/static/chunks/e5ff9ccb831e8ecf.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@700;900&family=Inter:wght@400;500;600&display=swap","style"]
0:{"buildId":"eLYnT0CJgM2JI_Ja2dh8u","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"firmalar","paramType":null,"paramKey":"firmalar","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
