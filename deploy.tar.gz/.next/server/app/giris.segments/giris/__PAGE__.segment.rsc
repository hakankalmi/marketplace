1:"$Sreact.fragment"
2:I[4209,["/_next/static/chunks/21d7fef99e51f235.js","/_next/static/chunks/8f3a2174c62b1531.js","/_next/static/chunks/237e48d2f3a0433b.js","/_next/static/chunks/fd27721d71c51603.js","/_next/static/chunks/ceb10ac8dbce4231.js"],"Nav"]
3:"$Sreact.suspense"
4:I[66472,["/_next/static/chunks/21d7fef99e51f235.js","/_next/static/chunks/8f3a2174c62b1531.js","/_next/static/chunks/237e48d2f3a0433b.js","/_next/static/chunks/fd27721d71c51603.js","/_next/static/chunks/ceb10ac8dbce4231.js"],"OtpForm"]
5:I[24415,["/_next/static/chunks/21d7fef99e51f235.js","/_next/static/chunks/8f3a2174c62b1531.js","/_next/static/chunks/237e48d2f3a0433b.js","/_next/static/chunks/fd27721d71c51603.js","/_next/static/chunks/ceb10ac8dbce4231.js"],"Footer"]
6:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
0:{"buildId":"_SpNzSZDtWGocJfwyNtJ2","rsc":["$","$1","c",{"children":[[["$","$L2",null,{}],["$","main",null,{"className":"min-h-screen bg-brand-bg flex items-center justify-center px-4 py-16","children":["$","$3",null,{"children":["$","$L4",null,{}]}]}],["$","$L5",null,{}]],[["$","script","script-0",{"src":"/_next/static/chunks/237e48d2f3a0433b.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/fd27721d71c51603.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/ceb10ac8dbce4231.js","async":true}]],["$","$L6",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@7"}]}]]}],"loading":null,"isPartial":false}
7:null
