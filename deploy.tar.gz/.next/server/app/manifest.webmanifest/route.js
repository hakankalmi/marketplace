var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/[root-of-the-server]__1e794d39._.js")
R.c("server/chunks/[root-of-the-server]__f5a6139b._.js")
R.c("server/chunks/_next-internal_server_app_manifest_webmanifest_route_actions_1bff3fca.js")
R.m(22945)
module.exports=R.m(22945).exports
