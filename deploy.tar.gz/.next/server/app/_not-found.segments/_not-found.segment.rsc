1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/2d5b9d6f1fbebdd8.js","/_next/static/chunks/d2be314c3ece3fbe.js","/_next/static/chunks/8f3a2174c62b1531.js"],"default"]
3:I[37457,["/_next/static/chunks/2d5b9d6f1fbebdd8.js","/_next/static/chunks/d2be314c3ece3fbe.js","/_next/static/chunks/8f3a2174c62b1531.js"],"default"]
0:{"buildId":"_SpNzSZDtWGocJfwyNtJ2","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
